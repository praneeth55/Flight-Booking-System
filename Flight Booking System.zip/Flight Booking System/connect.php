<?php 

    $vt=new mysqli ("localhost","root","","fly");
    

?>