<?php
require_once("parca/header.php");
require_once("parca/navbar.php");
?>

<div class="aboutdiv"> 
    <div class="sol" style="background-color:black; width:43.5%;height:600px; float:left;margin-left:50px;margin-top:50px;">
    <img  src="img/ata.jpeg" width="100%" height="100%" style="border-radius:14px;"/>

    </div>
    <div class="sag" style="background-color: white; width:50%; float:left; margin-left:1%; height:600px; overflow:auto; opacity:0.9;margin-right:50px;border-radius:14px;margin-top:50px;">
    <h3 style="text-align: center"> PRANEETH AIRLINES</h3>
    <p style="padding-left:15px;padding-right:15px;text-align:justify;">
    &nbsp &nbsp   In this website we can register and can create an account. Ahter that we need to login with our credentials and can book a flight which are available.

    </p>
    </div>
</div>

<?php
require_once("parca/footer.php");
?>