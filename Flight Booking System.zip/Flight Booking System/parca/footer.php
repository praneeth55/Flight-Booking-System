
</body>
<footer>  
        <div class="footerBox1" style="  width: 50%; height:10%;">
            <h1>PRANEETH AIRLINES</h1>
            <a href="https://www.facebook.com/"><i class="fab fa-facebook" ></i></a>
            <a href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
            <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
            <p style="font-size:13px;margin-left:70%;width:350px;"> </p>
        </div>
    
        <div class="footerBox2 " style="width:50%; height:10%;">    
            <h2 style="margin-right:63%;"></h2>  
            <div class="footer1">
                <p></p>
                <a href= style="color:white;"></a>
            </div>
            <div class="footer2">
                <p></p>
                <p style="margin-left:1%"></p>
            </div>
        </div>
            
        
    </div>
    
</footer>
</html>