<?php
require_once("parca/header.php");
require_once("parca/navbar.php");
?>
<div style="margin-left:30%;"   class="map"> 
<iframe
src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3890.0407858785975!2d80.15123961479146!3d12.84064099094193!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5259a4484200af%3A0x2edb13d73359cecd!2sVIT%20-%20Boy&#39;s%20Hostel%20-%20C%20Block!5e0!3m2!1sen!2sin!4v1605031826196!5m2!1sen!2sin" 
width="800px"
height="500px"
frameborder="0" 
style="border:0;" 
allowfullscreen=""
aria-hidden="false" 
tabindex="0">
</iframe>
</div>



<?php
require_once("parca/footer.php");
?>
